package Level;
public class Tile {
	public static final int TILE_GRASS = 0;
	public static final int TILE_DIRT = 1;
	public int tile;
	boolean  isPassable = true;
	public Tile(int TILE_TYPE){
		tile=TILE_TYPE;
		if(tile == 1)
			isPassable = false;
		else
			tile=0;
	}
}
