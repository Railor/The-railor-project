package Entity;

public class TestEntity extends Entity{

	public TestEntity(int x, int y) {
		super(x, y);
		
	}

}
