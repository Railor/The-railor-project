package Art;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;

import javax.imageio.ImageIO;

public class Bitmap {
    public int w, h;
    public int[] pixels;
    
    
    
    
}
